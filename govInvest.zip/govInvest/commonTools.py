# -*- coding: utf-8 -*-
'''
Created on 2021年5月12日

@author: hewei
'''

def returnNotNull(fieldList):
    if len(fieldList)>0:
        return fieldList[0]
        